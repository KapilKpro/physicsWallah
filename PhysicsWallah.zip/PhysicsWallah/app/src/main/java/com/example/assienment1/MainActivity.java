package com.example.assienment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    //private static final String URL_DATA = "https://my-json-server.typicode.com/easygautam/data/users";
    private List<ItemModel> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        list = new ArrayList<>();



        list.add(new ItemModel("https://d2bps9p1kiy4ka.cloudfront.net/5eb393ee95fab7468a79d189/019d5525-c906-4697-b8d1-7b9ed235abe6.png","Amit Mahajan","Chemistry","IIT Mumbai"));
        list.add(new ItemModel("https://d2bps9p1kiy4ka.cloudfront.net/5eb393ee95fab7468a79d189/71ec7e49-9229-46ab-ac71-71aefee195ff.png","Samapati Sinha","Biology","IIT Nagpur"));
        list.add(new ItemModel("https://d2bps9p1kiy4ka.cloudfront.net/5eb393ee95fab7468a79d189/4abd290c-6b46-4f6e-afde-35a229d7ce16.png","Yugsareen Kumar","Physics","IIT Mumbai"));
        list.add(new ItemModel("https://d2bps9p1kiy4ka.cloudfront.net/5eb393ee95fab7468a79d189/cc7dd5d6-1b3d-4fe3-ae49-30c39360ce5a.png","Pankaj Sijairya","Maths","IIT Nagpur"));
        list.add(new ItemModel("https://d2bps9p1kiy4ka.cloudfront.net/5eb393ee95fab7468a79d189/53022728-b6ed-43bf-ba9a-84acbf0df7df.png","Danish Zafar","English","IIT Mumbai"));
        ItemAdapter adapter = new ItemAdapter(list);
        recyclerView.setAdapter(adapter);
    }

}