package com.example.assienment1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.myViewHolder> {
    private List<ItemModel> itemModelList;

    public ItemAdapter(List<ItemModel> itemModelList) {
        this.itemModelList = itemModelList;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout,parent,false);
        return new  myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
      holder.setData(itemModelList.get(position).getUrl(),itemModelList.get(position).getTitle(),itemModelList.get(position).getDescription1(),
              itemModelList.get(position).getDescription2());
    }

    @Override
    public int getItemCount() {
        return itemModelList.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        private ImageView image;
        private TextView title;
        private TextView description1;
        private TextView description2;
        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image_view);
            title = itemView.findViewById(R.id.title_view);
            description1 = itemView.findViewById(R.id.description_view1);
            description2 = itemView.findViewById(R.id.description_view2);
        }
        private void setData(String url, final String title, final String description1,final String description2){
            Glide.with(itemView.getContext()).load(url).into(image);
            this.title.setText(title);
            this.description1.setText(description1);
            this.description2.setText(description2);

        }
    }
}
