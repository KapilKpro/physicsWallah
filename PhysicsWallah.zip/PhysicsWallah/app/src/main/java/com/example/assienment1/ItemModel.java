package com.example.assienment1;

public class ItemModel {
    private String url;
    private String title;
    private String description1;
    private String description2;

    public ItemModel(String url, String title, String description1, String description2) {
        this.url = url;
        this.title = title;
        this.description1 = description1;
        this.description2 = description2;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription1() {
        return description1;
    }

    public void setDescription1(String description1) {
        this.description1 = description1;
    }

    public String getDescription2() {
        return description2;
    }

    public void setDescription2(String description2) {
        this.description2 = description2;
    }
}
